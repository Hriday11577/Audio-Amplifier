# PCB Assembly Guide – Everyday Audio Enhancer

Universal (perfboard / strip-board) PCB, approx. 10 cm × 8 cm.

---

## Assembly Order (recommended)

Solder in this order to avoid access issues:

1. **Resistors** (all fixed values) — flat, no polarity issues
2. **Zener diode ZD1** (10 V) — cathode marked with band → toward VCC rail
3. **Signal diode D1** (1N4148) — cathode band → toward VR3 wiper
4. **Presets / trimpots** — VR2 (10 kΩ), VR3 (100 Ω)
5. **Ceramic / film capacitors** (non-polarised: C_HF 10 nF, C_trim 5 nF, C1 0.1 µF)
6. **Electrolytic capacitors** — observe polarity:
   - C2 (2.2 µF): + toward JFET drain
   - C8 (470 µF): + toward BC548 emitter
   - C4 (220 µF): + toward output node
   - C_supply (100 µF): + toward VCC
   - C_out (2200 µF): + toward output transistor emitters
7. **Volume pot VR1** (1 MΩ logarithmic) — off-board, panel-mount, wire connections
8. **Transistors** — in order T1 → T2 → T3 → T4 → T5

---

## Transistor Pinouts

| Device | Package | Pin order (flat face) |
|---|---|---|
| 2N5484 (T1) | TO-92 | Gate – Source – Drain |
| BC548  (T2) | TO-92 | Collector – Base – Emitter (C-B-E left to right) |
| BC639  (T3) | TO-92 | C – B – E |
| BD139  (T4) | TO-126 | Base – Collector – Emitter |
| BD140  (T5) | TO-126 | Base – Collector – Emitter |

> **BD139 / BD140 critical:** The metallic tab (flat back) must face the **centre of the board**. Both output transistors should be in thermal contact with a small aluminium heatsink or at minimum each other if running >0.5 W output.

---

## Net Connections (key nodes)

```
VCC (18 V) ─┬─ R6 (330Ω) ─ VCC10 (10 V via ZD1) ─ R1 ─ T1 drain
             ├─ R7 ─ Bootstrap node ─ R8 ─ Output
             └─ T4 collector

GND ─────────┬─ ZD1 cathode
             ├─ R2 bottom
             ├─ C_out– (negative terminal)
             └─ Speaker one terminal

Output node ─┬─ T4 emitter / T5 emitter
             ├─ R13 → T2 emitter (feedback)
             ├─ C4+ (bootstrap)
             └─ C_out+ → Speaker+
```

---

## Initial Power-Up Checklist

- [ ] Verify all electrolytic caps are installed with correct polarity
- [ ] Verify BD139 and BD140 metal tabs face board centre
- [ ] Disconnect speaker initially
- [ ] Apply 18 V supply; measure VCC10 → should be ~10 V ± 0.5 V
- [ ] Measure DC output node (collector junction T4/T5) → adjust VR2 until = VCC/2 ≈ 9 V
- [ ] Measure quiescent current of T4: adjust VR3 for 20–40 mA (Class AB sweet spot)
- [ ] Connect speaker; apply 1 kHz, 100 mV sine input; verify amplified output on oscilloscope
- [ ] Check for crossover notch at zero-crossing; if visible, increase VR3 slightly

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| No output, DC output = VCC | T4 saturated; VR2 not set | Adjust VR2 for VCC/2 at output node |
| No output, DC output = 0 V | T5 saturated or shorted | Check BD140 pinout and polarity |
| Crossover distortion (notch on scope) | VR3 too low | Increase VR3 to raise quiescent current |
| Oscillation / squealing | HF instability | Check C_HF (10 nF) and C_trim (5 nF) are fitted |
| Low volume | VR1 not logarithmic taper | Replace with log (Type C) pot |
| Hum on output | C_out or C_supply too small / old | Check 2200 µF and 100 µF caps |
